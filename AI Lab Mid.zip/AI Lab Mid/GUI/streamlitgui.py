import streamlit as st
import json
import networkx as nx
import matplotlib.pyplot as plt

from main import bfs, dfs, ucs, a_star, hill_climbing, heuristic

# =========================
# LOAD GRAPH
# =========================
if "graph" not in st.session_state:
    with open("graph.json") as f:
        st.session_state.graph = json.load(f)

graph = st.session_state.graph

# =========================
# LABELS (IMPORTANT FIX)
# =========================
labels = {
    "A": "Attacker",
    "B": "Firewall",
    "C": "Workstation",
    "D": "Mail Server",
    "E": "Web Server",
    "F": "Internal Server",
    "G": "Database",
    "H": "Backup Server",
    "I": "Admin System",
    "J": "Target Asset",
    "X": "Trap Node",
    "Y": "Loop Node"
}

# =========================
# SIDEBAR EDGE EDITOR (FIX)
# =========================
st.sidebar.title("🔧 Modify Edge Costs")

nodes = list(graph.keys())

# 🔥 show labels instead of raw IDs
src_label = st.sidebar.selectbox(
    "From Node",
    options=nodes,
    format_func=lambda x: labels.get(x, x)
)

if src_label:

    dst_label = st.sidebar.selectbox(
        "To Node",
        options=list(graph[src_label].keys()) if graph[src_label] else [],
        format_func=lambda x: labels.get(x, x)
    )

    if dst_label:

        new_weight = st.sidebar.number_input(
            f"Cost: {labels[src_label]} → {labels[dst_label]}",
            value=float(graph[src_label][dst_label]),
            min_value=1.0,
            step=1.0
        )

        if st.sidebar.button("Update Cost"):
            graph[src_label][dst_label] = new_weight
            st.session_state.graph = graph
            st.sidebar.success(
                f"Updated: {labels[src_label]} → {labels[dst_label]}"
            )
# =========================
# ALGORITHM SELECTION
# =========================
st.title("Attack Path Simulation System")

algo = st.selectbox(
    "Select Algorithm",
    ["BFS", "DFS", "UCS", "A*", "Hill Climbing"]
)

start, goal = "A", "J"

# =========================
# RUN ALGORITHM
# =========================
if st.button("Run"):
    if algo == "BFS":
        res = bfs(graph, start, goal)
    elif algo == "DFS":
        res = dfs(graph, start, goal)
    elif algo == "UCS":
        res = ucs(graph, start, goal)
    elif algo == "A*":
        res = a_star(graph, start, goal, heuristic)
    else:
        res = hill_climbing(graph, start, goal, heuristic)

    st.session_state["res"] = res

res = st.session_state.get("res")

# =========================
# FIXED NON-OVERLAPPING LAYOUT
# =========================
pos = {
    "A": (0, 3),

    "B": (-2, 2),
    "C": (0, 2),
    "D": (2, 2),

    "E": (-2, 1),
    "F": (-1, 1),
    "G": (0, 1),
    "H": (1, 1),
    "I": (2, 1),

    "J": (0, 0),

    "X": (3, 2),
    "Y": (3, 1)
}

# =========================
# BUILD GRAPH
# =========================
G = nx.DiGraph()

for u in graph:
    for v, w in graph[u].items():
        G.add_edge(u, v, weight=w)

# =========================
# DRAW GRAPH
# =========================
fig, ax = plt.subplots(figsize=(10, 6))

# Nodes
nx.draw(
    G,
    pos,
    labels=labels,   # 🔥 FIX: shows meaningful names
    with_labels=True,
    node_color="lightblue",
    node_size=3500,
    font_size=8,
    font_weight="bold",
    arrows=True,
    ax=ax
)

# Edge weights
edge_labels = nx.get_edge_attributes(G, "weight")

nx.draw_networkx_edge_labels(
    G,
    pos,
    edge_labels=edge_labels,
    font_size=9,
    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.7),
    ax=ax
)

# Highlight path
if res and "path" in res:
    path_edges = list(zip(res["path"], res["path"][1:]))

    nx.draw_networkx_edges(
        G,
        pos,
        edgelist=path_edges,
        edge_color="red",
        width=3,
        arrows=True,
        ax=ax
    )

ax.set_title("Cybersecurity Attack Graph", fontsize=14)
ax.axis("off")

st.pyplot(fig)

# =========================
# RESULT DISPLAY
# =========================
if res:
    st.subheader("Result")

    if "path" in res:
        st.write(" → ".join([labels[n] for n in res["path"]]))

    st.json(res)

# =========================
# COMPARISON TABLE
# =========================
if st.button("Run All Algorithms Comparison"):

    results = [
        bfs(graph, start, goal),
        dfs(graph, start, goal),
        ucs(graph, start, goal),
        a_star(graph, start, goal, heuristic),
        hill_climbing(graph, start, goal, heuristic),
    ]

    st.subheader("Algorithm Comparison")

    table = []

    for r in results:
        if r:
            table.append({
                "Algorithm": r["algorithm"],
                "Path": " → ".join([labels[n] for n in r["path"]]) if "path" in r else "N/A",
                "Cost": r["cost"],
                "Expanded Nodes": r["expanded"],
                "Time (ms)": round(r["time"], 2)
            })

    st.table(table)