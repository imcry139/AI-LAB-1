import json
import time
import heapq
from collections import deque

def load_graph():
    with open("graph.json", "r") as f:
        return json.load(f)

start = "A"
goal = "J"

heuristic = {
    "A": 6, "B": 5, "C": 5,
    "D": 4, "E": 3,
    "F": 4, "G": 3,
    "H": 2, "I": 2,
    "J": 0,
    "X": 1, "Y": 1
}

# ---------------- BFS ----------------
def bfs(graph, start, goal):
    start_time = time.time()
    q = deque([(start, [start])])
    visited = set()
    expanded = 0

    while q:
        node, path = q.popleft()
        if node in visited:
            continue
        visited.add(node)
        expanded += 1

        if node == goal:
            cost = sum(graph[path[i]][path[i+1]] for i in range(len(path)-1))
            return {"algorithm":"BFS","path":path,"cost":cost,"expanded":expanded,"time":(time.time()-start_time)*1000}

        for n in graph[node]:
            q.append((n, path+[n]))

    return None

# ---------------- DFS ----------------
def dfs(graph, start, goal):
    start_time = time.time()
    stack = [(start, [start])]
    visited = set()
    expanded = 0

    while stack:
        node, path = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        expanded += 1

        if node == goal:
            cost = sum(graph[path[i]][path[i+1]] for i in range(len(path)-1))
            return {"algorithm":"DFS","path":path,"cost":cost,"expanded":expanded,"time":(time.time()-start_time)*1000}

        for n in graph[node]:
            stack.append((n, path+[n]))

    return None

# ---------------- UCS ----------------
def ucs(graph, start, goal):
    start_time = time.time()
    pq = [(0, start, [start])]
    visited = {}
    expanded = 0

    while pq:
        cost, node, path = heapq.heappop(pq)

        if node in visited and visited[node] <= cost:
            continue

        visited[node] = cost
        expanded += 1

        if node == goal:
            return {"algorithm":"UCS","path":path,"cost":cost,"expanded":expanded,"time":(time.time()-start_time)*1000}

        for n, w in graph[node].items():
            heapq.heappush(pq, (cost+w, n, path+[n]))

    return None

# ---------------- A* ----------------
def a_star(graph, start, goal, heuristic):
    start_time = time.time()
    pq = [(heuristic[start], 0, start, [start])]
    visited = {}
    expanded = 0

    while pq:
        f, g, node, path = heapq.heappop(pq)

        if node in visited and visited[node] <= g:
            continue

        visited[node] = g
        expanded += 1

        if node == goal:
            return {"algorithm":"A*","path":path,"cost":g,"expanded":expanded,"time":(time.time()-start_time)*1000}

        for n, w in graph[node].items():
            ng = g + w
            heapq.heappush(pq, (ng + heuristic[n], ng, n, path+[n]))

    return None

# ---------------- Hill Climbing ----------------
def hill_climbing(graph, start, goal, heuristic):
    start_time = time.time()
    node = start
    path = [node]
    expanded = 0

    while node != goal:
        expanded += 1
        neighbors = list(graph[node].keys())

        if not neighbors:
            break

        next_node = min(neighbors, key=lambda x: heuristic[x])

        if heuristic[next_node] >= heuristic[node]:
            return {
                "algorithm":"Hill Climbing",
                "path":path,
                "cost":None,
                "expanded":expanded,
                "time":(time.time()-start_time)*1000,
                "reached":False,
                "failure_reason":"Local optimum"
            }

        node = next_node
        path.append(node)

    return {
        "algorithm":"Hill Climbing",
        "path":path,
        "cost":None,
        "expanded":expanded,
        "time":(time.time()-start_time)*1000,
        "reached":node==goal
    }

# ---------------- Minimax ----------------
def minimax(depth, index, is_max, values):
    if depth == 0:
        return values[index]

    if is_max:
        return max(
            minimax(depth-1,index*2,False,values),
            minimax(depth-1,index*2+1,False,values)
        )
    else:
        return min(
            minimax(depth-1,index*2,True,values),
            minimax(depth-1,index*2+1,True,values)
        )

# ---------------- Alpha Beta ----------------
def alpha_beta(depth, index, is_max, values, alpha, beta):
    if depth == 0:
        return values[index]

    if is_max:
        for i in range(2):
            val = alpha_beta(depth-1,index*2+i,False,values,alpha,beta)
            alpha = max(alpha,val)
            if beta <= alpha:
                break
        return alpha
    else:
        for i in range(2):
            val = alpha_beta(depth-1,index*2+i,True,values,alpha,beta)
            beta = min(beta,val)
            if beta <= alpha:
                break
        return beta